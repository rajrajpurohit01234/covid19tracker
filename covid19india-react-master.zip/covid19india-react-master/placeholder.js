// Placeholder file to give input to rollup

export default function () {}
